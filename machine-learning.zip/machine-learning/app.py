from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import joblib

loaded_model = joblib.load('./model/model.pkl')
loaded_label_encoder = joblib.load('./model/label_encoder.pkl')

app = Flask(__name__)

app.template_folder = 'templates'

@app.route("/predict", methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        try:
            # get data from request body
            answer = request.get_json(force=True)
            
             # Transform to DataFrame
            input_data = pd.DataFrame([answer])

            # predict using loaded model
            predictions = loaded_model.predict(input_data)

            # Decode predictions using label encoder
            decoded_predictions = loaded_label_encoder.inverse_transform(predictions)

            # Return predictions as JSON
            return jsonify({'predictions': list(decoded_predictions)}), 200
        
        except Exception as e:
            print(e)
            return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)